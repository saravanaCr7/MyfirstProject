import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PersonserverService } from '../service/personserver.service';
@Component({
  selector: 'app-addperson',
  templateUrl: './addperson.component.html',
  styleUrls: ['./addperson.component.css']
})
export class AddpersonComponent implements OnInit {

  addPerson=new FormGroup({
    name:new FormControl('',[Validators.required, Validators.minLength(5)]),
    email:new FormControl('',[Validators.required, Validators.email]),
    dob:new FormControl(''),
    avatar:new FormControl(''),
    country:new FormControl(''),
  })
  get name(){return this.addPerson.get('name')}
  get email(){return this.addPerson.get('email')}
  get dob(){return this.addPerson.get('dob')}
  get avatar(){return this.addPerson.get('avatar')}
  get country(){return this.addPerson.get('country')}
  constructor(private person :PersonserverService,private router: Router) { }

  ngOnInit(): void {
  }
  
  collectPerson(){
 this.person.savePerson(this.addPerson.value).subscribe((result)=>{
      console.log("result is  here",result)
      this.router.navigate(['/list']);
    });
  }

}
