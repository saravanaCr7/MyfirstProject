import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import{AddpersonComponent} from './addperson/addperson.component'
import{ListpersonComponent} from './listperson/listperson.component'
import{UpdatepersonComponent} from './updateperson/updateperson.component'

const routes: Routes = [

  {component:AddpersonComponent,path:'add'},
  {component:ListpersonComponent,path:'list'},
  {component:UpdatepersonComponent,path:'update/:id'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
