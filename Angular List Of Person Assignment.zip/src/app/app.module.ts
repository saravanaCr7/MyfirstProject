import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {  ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import{AddpersonComponent} from './addperson/addperson.component'
import{ListpersonComponent} from './listperson/listperson.component'
import{UpdatepersonComponent} from './updateperson/updateperson.component'
@NgModule({
  declarations: [
    AppComponent,
    AddpersonComponent,
    ListpersonComponent,
    UpdatepersonComponent,
    
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
     ReactiveFormsModule,
     HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
