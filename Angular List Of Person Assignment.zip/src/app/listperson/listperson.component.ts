import { Component, OnInit } from '@angular/core';
import { PersonserverService } from '../service/personserver.service';
@Component({
  selector: 'app-listperson',
  templateUrl: './listperson.component.html',
  styleUrls: ['./listperson.component.css']
})
export class ListpersonComponent implements OnInit {

  currentdate=new Date().getFullYear();
  constructor(private person: PersonserverService) { }
  collection: any = [];
  color: string;

  ngOnInit(): void {
    this.person.getList().subscribe((result) => {
      console.log(result)
      this.collection = result;
    });
  }
  deletePerson(item) {
    this.collection.splice(item-1,1)
    this.person.deletePerson(item).subscribe((result) => {
      console.log(result)
      this.collection=result;
    });

  }
}
