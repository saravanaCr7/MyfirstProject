import { TestBed } from '@angular/core/testing';

import { PersonserverService } from './personserver.service';

describe('PersonserverService', () => {
  let service: PersonserverService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PersonserverService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
