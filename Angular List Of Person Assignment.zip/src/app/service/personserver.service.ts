import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class PersonserverService {
  url="http://localhost:3000/persons";
  constructor(private http: HttpClient) { }
    getList(){
      return this.http.get(this.url);
    }
    savePerson(data){
      return this.http.post(this.url,data);
    }
    deletePerson(id){
      return this.http.delete(`${this.url}/${id}`);
    }
    getCurrentPerson(id){

      return this.http.get(`${this.url}/${id}`);
    }
    updatePerson(id,data){
      return this.http.put(`${this.url}/${id}`,data);
    }
}

