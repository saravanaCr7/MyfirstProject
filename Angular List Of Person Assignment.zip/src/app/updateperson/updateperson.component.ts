import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import{ ActivatedRoute, Router } from'@angular/router';
import { PersonserverService } from '../service/personserver.service';
@Component({
  selector: 'app-updateperson',
  templateUrl: './updateperson.component.html',
  styleUrls: ['./updateperson.component.css']
})
export class UpdatepersonComponent implements OnInit {

  editPerson=new FormGroup({
    name:new FormControl(''),
    email:new FormControl(''),
    dob:new FormControl(''),
    avatar:new FormControl(''),
    country:new FormControl(''),
  })
  constructor(private router :ActivatedRoute ,private person:PersonserverService,private router1 : Router) { }

  ngOnInit(): void {
    this.person.getCurrentPerson(this.router.snapshot.params.id).subscribe((result)=>{
      console.log(result);
      this.editPerson=new FormGroup({
        name:new FormControl(result['name']),
        email:new FormControl(result['email']),
        dob:new FormControl(result['dob']),
        avatar:new FormControl(result['avatar']),
        country:new FormControl(result['country']),
      })

    })
  }
  collectionEdit(){
    console.warn(this.editPerson.value);
    this.person.updatePerson(this.router.snapshot.params.id,this.editPerson.value).subscribe((result)=>{
      console.log(result)
    });
    this.router1.navigate(['/list']);
  }

}
